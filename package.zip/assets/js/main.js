$('.beneficiaries-slider').slick({
    slidesToShow: 4,
    slidesToScroll: 1,
    dots: false,
    arrows: false,
    centerMode: true,
    padding:0,
    speed:1300,
    autoplay: true,
    autoplaySpeed: 2000
    });